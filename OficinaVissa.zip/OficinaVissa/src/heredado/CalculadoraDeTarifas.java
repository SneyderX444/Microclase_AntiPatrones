package heredado;

public class CalculadoraDeTarifas {
    private static int edicionesPrecioBase = 0;
    private double tarifaBase = 50.0;

    public void setTarifaBase(double nuevaTarifa) {
        // Para demostrar la duplicacion en la prueba: se debe modificar en cada metodo/lugar
        this.tarifaBase = nuevaTarifa;
    }

    public static void registrarEdicionManual() {
        edicionesPrecioBase++;
    }

    public static int getEdicionesPrecioBase() {
        return edicionesPrecioBase;
    }

    public double visaTurista(int meses) {
        double total = tarifaBase * meses;
        total = total + 10;
        return total;
    }

    public double visaEstudiante(int meses) {
        double total = tarifaBase * meses;
        total = total + 10;
        return total * 0.5;
    }

    public double visaTrabajo(int meses) {
        double total = tarifaBase * meses;
        total = total + 10;
        return total * 1.5;
    }
}
