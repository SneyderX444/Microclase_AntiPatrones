package heredado;

class CorreoServicio {
    public void avisarCancelacion() {
        System.out.println("[CorreoServicio] Envio correo de cancelacion.");
    }
}

class CitasServicio {
    public void liberarCupo() {
        System.out.println("[CitasServicio] Cupo de cita liberado.");
    }
}

class PagosServicio {
    public void reembolsar() {
        System.out.println("[PagosServicio] Reembolso procesado correctamente.");
    }
}

public class SolicitudAcoplada {
    private String estado = "ACTIVA";
    private CorreoServicio correo = new CorreoServicio();
    private CitasServicio citas = new CitasServicio();
    private PagosServicio pagos = new PagosServicio();

    public void cancelar() {
        estado = "CANCELADA";
        correo.avisarCancelacion();
        citas.liberarCupo();
        // NOTA: Se olvidaron de llamar a pagos.reembolsar();
    }

    public String getEstado() {
        return estado;
    }
}
