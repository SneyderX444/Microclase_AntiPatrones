package main;

import heredado.*;
import rescatado.*;
import rescatado.strategy.*;
import rescatado.observer.*;

public class Main {
    public static void main(String[] args) {
        imprimirEncabezado();

        ejecutarCaso1();
        ejecutarCaso2();
        ejecutarCaso3();
        ejecutarCaso4();
        ejecutarCaso5();
    }

    private static void imprimirEncabezado() {
        System.out.println("===============================================================================");
        System.out.println("       UNIVERSIDAD DISTRITAL FRANCISCO JOSÉ DE CALDAS - INGENIERÍA DE SISTEMAS");
        System.out.println("              TALLER: LA OFICINA DE VISAS DEL CAOS (ANTIPATRONES)");
        System.out.println("===============================================================================\n");
    }

    private static void ejecutarCaso1() {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("CASO 1: God Object (OficinaDeTodo vs Clases Separadas por Responsabilidad)");
        System.out.println("-------------------------------------------------------------------------------");
        
        System.out.println("\n>>> VERSIÓN HEREDADA (God Object - Ramiro lo hace todo):");
        OficinaDeTodo ramiro = new OficinaDeTodo();
        ramiro.procesar("Juan Perez", "PAS123456", 150.0);

        System.out.println("\n>>> VERSIÓN RESCATADA (Principio SRP - Clases con responsabilidad única):");
        TramitadorVisas tramitador = new TramitadorVisas();
        tramitador.procesarTramite("Juan Perez", "PAS123456", 150.0);
        System.out.println();
    }

    private static void ejecutarCaso2() {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("CASO 2: Copy-Paste Programming (Modificación de Tarifa Base)");
        System.out.println("-------------------------------------------------------------------------------");

        System.out.println("\n>>> VERSIÓN HEREDADA (Lógica duplicada):");
        CalculadoraDeTarifas calcHeredada = new CalculadoraDeTarifas();
        CalculadoraDeTarifas.registrarEdicionManual();
        CalculadoraDeTarifas.registrarEdicionManual();
        CalculadoraDeTarifas.registrarEdicionManual();
        calcHeredada.setTarifaBase(60.0);

        double tHeredadaTurista = calcHeredada.visaTurista(2);
        double tHeredadaEstudiante = calcHeredada.visaEstudiante(2);
        double tHeredadaTrabajo = calcHeredada.visaTrabajo(2);

        System.out.printf("Tarifas (Base $60, 2 meses): Turista=$%.2f | Estudiante=$%.2f | Trabajo=$%.2f\n",
                tHeredadaTurista, tHeredadaEstudiante, tHeredadaTrabajo);
        System.out.println("Lugares/Archivos modificados manualmente en el código: " + CalculadoraDeTarifas.getEdicionesPrecioBase());

        System.out.println("\n>>> VERSIÓN RESCATADA (Patrón Strategy):");
        CalculadoraTarifasRescatada calcRescatada = new CalculadoraTarifasRescatada();
        calcRescatada.setTarifaBase(60.0);

        double tRescatadaTurista = calcRescatada.calcularTarifa(new TarifaTurista(), 2);
        double tRescatadaEstudiante = calcRescatada.calcularTarifa(new TarifaEstudiante(), 2);
        double tRescatadaTrabajo = calcRescatada.calcularTarifa(new TarifaTrabajo(), 2);

        System.out.printf("Tarifas (Base $60, 2 meses): Turista=$%.2f | Estudiante=$%.2f | Trabajo=$%.2f\n",
                tRescatadaTurista, tRescatadaEstudiante, tRescatadaTrabajo);
        System.out.println("Lugares/Archivos modificados en el código: " + CalculadoraTarifasRescatada.getEdicionesPrecioBase());
        System.out.println("Resultado: El precio final coincide exactamente ($" + tRescatadaTurista + " == $" + tHeredadaTurista + "), pero la mantenibilidad se optimizó a 1 solo punto.");
        System.out.println();
    }

    private static void ejecutarCaso3() {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("CASO 3: Magic Numbers (Números Misteriosos vs Enum TipoVisa)");
        System.out.println("-------------------------------------------------------------------------------");

        EvaluadorMagico evHeredado = new EvaluadorMagico();
        EvaluadorRescatado evRescatado = new EvaluadorRescatado();

        System.out.println("\n>>> PRUEBA 1: Tipo 2 (Estudiante) con Edad 20");
        System.out.println("Heredado (evaluar(2, 20)): " + evHeredado.evaluar(2, 20));
        System.out.println("Rescatado (evaluar(TipoVisa.ESTUDIANTE, 20)): " + evRescatado.evaluar(TipoVisa.ESTUDIANTE, 20));

        System.out.println("\n>>> PRUEBA 2: Tipo inválido/desconocido 9");
        System.out.println("Heredado (evaluar(9, 20)): " + evHeredado.evaluar(9, 20) + " (Rechazo en silencio, no explica causa)");
        System.out.print("Rescatado (evaluarPorCodigo(9, 20)): ");
        String resRescatado = evRescatado.evaluarPorCodigo(9, 20);
        System.out.println("Resultado: " + resRescatado);
        System.out.println();
    }

    private static void ejecutarCaso4() {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("CASO 4: Acoplamiento Fuerte (Llamadas manuales vs Patrón Observer)");
        System.out.println("-------------------------------------------------------------------------------");

        System.out.println("\n>>> VERSIÓN HEREDADA (Acoplamiento fuerte):");
        SolicitudAcoplada solHeredada = new SolicitudAcoplada();
        solHeredada.cancelar();
        System.out.println("ALERTA HEREDADA: ¡Se olvidó llamar a PagosServicio! El viajero perdió su reembolso.");

        System.out.println("\n>>> VERSIÓN RESCATADA (Patrón Observer):");
        SolicitudRescatada solRescatada = new SolicitudRescatada("SOL-2026-99", "Sofia Gomez");
        solRescatada.agregarObservador(new ServicioCorreoObserver());
        solRescatada.agregarObservador(new ServicioCitasObserver());
        solRescatada.agregarObservador(new ServicioPagosObserver());
        
        solRescatada.cancelar();
        System.out.println("Resultado: La clase SolicitudRescatada no conoce los servicios concretos, pero todos se enteraron y se ejecutó el reembolso.");
        System.out.println();
    }

    private static void ejecutarCaso5() {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("CASO 5: Integración del Viaje Completo y Tabla Resumen");
        System.out.println("-------------------------------------------------------------------------------");

        System.out.println("\n--- SIMULACIÓN DE FLUJO COMPLETO CON LA VERSIÓN RESCATADA ---");
        String viajero = "Carlos Mendoza";
        String pasaporte = "COL987654";
        int edad = 24;
        TipoVisa tipoVisa = TipoVisa.ESTUDIANTE;
        int duracionMeses = 6;

        System.out.println("1. EVALUACIÓN:");
        EvaluadorRescatado evaluador = new EvaluadorRescatado();
        String estadoEval = evaluador.evaluar(tipoVisa, edad);
        System.out.println("   Resultado evaluación para " + viajero + " (" + tipoVisa.getDescripcion() + "): " + estadoEval);

        System.out.println("\n2. CÁLCULO DE TARIFA:");
        CalculadoraTarifasRescatada calculadora = new CalculadoraTarifasRescatada();
        double costoTotal = calculadora.calcularTarifa(new TarifaEstudiante(), duracionMeses);
        System.out.println("   Costo total calculado para " + duracionMeses + " meses: $" + costoTotal);

        System.out.println("\n3. TRÁMITE Y COBRO:");
        TramitadorVisas tramitador = new TramitadorVisas();
        tramitador.procesarTramite(viajero, pasaporte, costoTotal);

        System.out.println("\n4. SOLICITUD Y CANCELACIÓN POSTERIOR:");
        SolicitudRescatada solicitud = new SolicitudRescatada("SOL-2026-777", viajero);
        solicitud.agregarObservador(new ServicioCorreoObserver());
        solicitud.agregarObservador(new ServicioCitasObserver());
        solicitud.agregarObservador(new ServicioPagosObserver());
        solicitud.cancelar();

        System.out.println("\n=======================================================================================================================");
        System.out.println("                                      TABLA FINAL DE ANTIPATRONES CAPTURADOS");
        System.out.println("=======================================================================================================================");
        System.out.printf("| %-22s | %-45s | %-42s |%n", "ANTIPATRÓN", "SÍNTOMA EN EL CONSULADO", "SOLUCIÓN APLICADA");
        System.out.println("=======================================================================================================================");
        System.out.printf("| %-22s | %-45s | %-42s |%n", "1. God Object", "Ramiro/OficinaDeTodo asume todas las tareas", "Principio SRP (Clases por responsabilidad)");
        System.out.printf("| %-22s | %-45s | %-42s |%n", "2. Copy-Paste", "Cálculo de tarifado duplicado 3 veces", "Patrón Strategy (EstrategiaTarifa)");
        System.out.printf("| %-22s | %-45s | %-42s |%n", "3. Magic Numbers", "Números misteriosos como 1, 2, 3 o 0.5", "Enum TipoVisa con constantes claras");
        System.out.printf("| %-22s | %-45s | %-42s |%n", "4. Acoplamiento Fuerte", "Llamadas manuales a servicios olvidan pagos", "Patron Observer (Suscriptores desacoplados)");
        System.out.println("=======================================================================================================================\n");
    }
}