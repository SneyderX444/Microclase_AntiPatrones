package rescatado.strategy;

public class CalculadoraTarifasRescatada {
    private double tarifaBase = 50.0;
    private static int edicionesPrecioBase = 0;

    public void setTarifaBase(double nuevaTarifa) {
        this.tarifaBase = nuevaTarifa;
        edicionesPrecioBase++; // Un solo punto de cambio
    }

    public static int getEdicionesPrecioBase() {
        return edicionesPrecioBase;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    public double calcularTarifa(EstrategiaTarifa estrategia, int meses) {
        return estrategia.calcular(tarifaBase, meses);
    }
}
