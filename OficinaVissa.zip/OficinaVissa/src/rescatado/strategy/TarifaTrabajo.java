package rescatado.strategy;

public class TarifaTrabajo implements EstrategiaTarifa {
    @Override
    public double calcular(double tarifaBase, int meses) {
        return ((tarifaBase * meses) + 10) * 1.5;
    }
}
