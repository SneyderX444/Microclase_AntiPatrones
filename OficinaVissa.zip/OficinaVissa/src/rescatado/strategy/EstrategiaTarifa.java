package rescatado.strategy;

public interface EstrategiaTarifa {
    double calcular(double tarifaBase, int meses);
}
