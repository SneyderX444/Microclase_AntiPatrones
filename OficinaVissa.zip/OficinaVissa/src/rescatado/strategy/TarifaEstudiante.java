package rescatado.strategy;

public class TarifaEstudiante implements EstrategiaTarifa {
    @Override
    public double calcular(double tarifaBase, int meses) {
        return ((tarifaBase * meses) + 10) * 0.5;
    }
}

