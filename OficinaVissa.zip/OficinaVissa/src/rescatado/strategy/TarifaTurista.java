package rescatado.strategy;

public class TarifaTurista implements EstrategiaTarifa {
    @Override
    public double calcular(double tarifaBase, int meses) {
        return (tarifaBase * meses) + 10;
    }
}

