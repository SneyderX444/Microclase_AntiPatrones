package rescatado;

public class CajaPagos {
    public void cobrar(String nombre, double monto) {
        System.out.println("[CajaPagos] Cobrando $" + monto + " a " + nombre);
    }
}
