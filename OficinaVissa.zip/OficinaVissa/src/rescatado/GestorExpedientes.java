package rescatado;

public class GestorExpedientes {
    public void guardar(String nombre) {
        System.out.println("[GestorExpedientes] Guardando expediente de " + nombre);
    }
}
