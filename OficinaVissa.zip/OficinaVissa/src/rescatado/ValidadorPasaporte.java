package rescatado;

public class ValidadorPasaporte {
    public boolean esValido(String pasaporte) {
        return pasaporte != null && pasaporte.length() >= 6;
    }
}
