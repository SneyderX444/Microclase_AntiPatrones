package rescatado;

public class TramitadorVisas {
    private ValidadorPasaporte validador = new ValidadorPasaporte();
    private CajaPagos caja = new CajaPagos();
    private GestorExpedientes expedientes = new GestorExpedientes();
    private NotificadorCorreo correo = new NotificadorCorreo();

    public boolean procesarTramite(String nombre, String pasaporte, double precio) {
        if (!validador.esValido(pasaporte)) {
            System.out.println("[TramitadorVisas] Pasaporte invalido para " + nombre);
            return false;
        }
        caja.cobrar(nombre, precio);
        expedientes.guardar(nombre);
        correo.enviarNotificacion(nombre, "su visa va en camino");
        return true;
    }
}
