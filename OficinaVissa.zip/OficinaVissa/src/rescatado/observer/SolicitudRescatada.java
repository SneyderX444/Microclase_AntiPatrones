package rescatado.observer;

import java.util.ArrayList;
import java.util.List;

public class SolicitudRescatada {
    private String idSolicitud;
    private String nombreViajero;
    private String estado = "ACTIVA";
    private List<ObservadorCancelacion> observadores = new ArrayList<>();

    public SolicitudRescatada(String idSolicitud, String nombreViajero) {
        this.idSolicitud = idSolicitud;
        this.nombreViajero = nombreViajero;
    }

    public void agregarObservador(ObservadorCancelacion obs) {
        observadores.add(obs);
    }

    public void removerObservador(ObservadorCancelacion obs) {
        observadores.remove(obs);
    }

    public void cancelar() {
        this.estado = "CANCELADA";
        System.out.println("[Solicitud] Cancelando solicitud " + idSolicitud + " de " + nombreViajero + "...");
        notificarObservadores();
    }

    private void notificarObservadores() {
        for (ObservadorCancelacion obs : observadores) {
            obs.alCancelar(idSolicitud, nombreViajero);
        }
    }

    public String getEstado() {
        return estado;
    }
}
