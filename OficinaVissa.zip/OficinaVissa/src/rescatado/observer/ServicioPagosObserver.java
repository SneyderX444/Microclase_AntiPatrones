package rescatado.observer;

public class ServicioPagosObserver implements ObservadorCancelacion {
    @Override
    public void alCancelar(String idSolicitud, String nombreViajero) {
        System.out.println("[PagosObserver] Procesando reembolso automatico para " + nombreViajero);
    }
}
