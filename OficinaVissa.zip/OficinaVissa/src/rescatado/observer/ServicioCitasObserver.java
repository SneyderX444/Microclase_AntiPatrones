package rescatado.observer;

public class ServicioCitasObserver implements ObservadorCancelacion {
    @Override
    public void alCancelar(String idSolicitud, String nombreViajero) {
        System.out.println("[CitasObserver] Liberando cupo de la cita asignada para " + nombreViajero);
    }
}

