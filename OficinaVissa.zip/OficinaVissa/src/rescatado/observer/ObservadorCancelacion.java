package rescatado.observer;

public interface ObservadorCancelacion {
    void alCancelar(String idSolicitud, String nombreViajero);
}
