package rescatado.observer;

public class ServicioCorreoObserver implements ObservadorCancelacion {
    @Override
    public void alCancelar(String idSolicitud, String nombreViajero) {
        System.out.println("[CorreoObserver] Notificando via email la cancelacion a " + nombreViajero);
    }
}

