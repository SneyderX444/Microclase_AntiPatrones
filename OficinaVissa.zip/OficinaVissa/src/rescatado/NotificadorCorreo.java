package rescatado;

public class NotificadorCorreo {
    public void enviarNotificacion(String nombre, String mensaje) {
        System.out.println("[NotificadorCorreo] Correo para " + nombre + ": " + mensaje);
    }
}
