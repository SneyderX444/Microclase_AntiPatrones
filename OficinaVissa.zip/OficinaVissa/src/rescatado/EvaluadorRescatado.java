package rescatado;

public class EvaluadorRescatado {

    public String evaluar(TipoVisa tipo, int edad) {
        if (tipo == null) {
            System.out.println("[Evaluador] ERROR: Tipo de visa no reconocido/invalido.");
            return "RECHAZADA (TIPO INVALIDO)";
        }

        if (edad >= tipo.getEdadMinima() && edad <= tipo.getEdadMaxima()) {
            return "APROBADA";
        } else {
            return "RECHAZADA (EDAD FUERA DE RANGO: Requiere entre " + tipo.getEdadMinima() + " y " + tipo.getEdadMaxima() + " años)";
        }
    }

    public String evaluarPorCodigo(int codigo, int edad) {
        TipoVisa tipo = TipoVisa.desdeCodigo(codigo);
        if (tipo == null) {
            System.out.println("[EvaluadorRescatado] ERROR: El codigo " + codigo + " no corresponde a ningun TipoVisa valido.");
            return "RECHAZADA (TIPO INVALIDO)";
        }
        return evaluar(tipo, edad);
    }
}
