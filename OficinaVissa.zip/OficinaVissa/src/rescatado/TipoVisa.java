package rescatado;

public enum TipoVisa {
    TURISMO(1, 18, 120, "Visa de Turismo"),
    ESTUDIANTE(2, 16, 30, "Visa de Estudiante"),
    TRABAJO(3, 18, 65, "Visa de Trabajo");

    private final int codigo;
    private final int edadMinima;
    private final int edadMaxima;
    private final String descripcion;

    TipoVisa(int codigo, int edadMinima, int edadMaxima, String descripcion) {
        this.codigo = codigo;
        this.edadMinima = edadMinima;
        this.edadMaxima = edadMaxima;
        this.descripcion = descripcion;
    }

    public int getCodigo() { return codigo; }
    public int getEdadMinima() { return edadMinima; }
    public int getEdadMaxima() { return edadMaxima; }
    public String getDescripcion() { return descripcion; }

    public static TipoVisa desdeCodigo(int codigo) {
        for (TipoVisa t : values()) {
            if (t.codigo == codigo) return t;
        }
        return null;
    }
}
